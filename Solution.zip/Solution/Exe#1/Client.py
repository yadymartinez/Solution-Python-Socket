import random
import string
import socket
import logging
from datetime import datetime


def Strings_Generator(num_str, fname):
   file_name = fname+'/chains.txt'
   file = open(file_name, 'w')
   for x in range(num_str):
       my_string = ""
       len_string = random.randint(50,100)
       num_space = random.randint(3,5)
       segment = (len_string-num_space)//(num_space + 1) # Calculate the segments len
       last_segment = len_string - num_space - (segment * num_space) # Calculate the last segment
       for j in range(num_space): # Create each segment separate by blanckspace
           my_string += "".join(random.choice(string.ascii_letters + string.digits) # Generate the segments without blanckspace
              for _ in range(segment)
            )
           my_string += " " # Add the blanckspace before the segment
           j+=1
       my_string += "".join(random.choice(string.ascii_letters + string.digits)
        for _ in range(last_segment) # Generate the last segment
           )
       file.write(my_string + '\n')
   file.close()
   return file_name

def Read_File(file_name):  # Read the string file
  with (open (file_name, 'r')) as fname:
    strings = fname.readlines()
  fname.close()
  return strings

def Send_Server(server_address, message): # Send and Received message from Server

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    logging.info('Connecting to {} port {}'.format(*server_address))
    sock.connect(server_address)
    sock.sendto(message.encode('utf-8'), server_address) # Sending data to server as string
    logging.info('String data send from client {}'.format(message)) # Save data on client logfile
    results = sock.recv(2048).decode('utf-8') # Received results as string
    logging.info('Server string result weight metric {}'.format(results))
    logging.debug(results)

def Start(server_address, logfile_client, num_str, string_file):
    start_time = datetime.now()
    if num_str ==0 : num_str = 100000
    logging.basicConfig(level=logging.DEBUG, filename=logfile_client)
    file_name=Strings_Generator(num_str, string_file)
    logging.info('Generate Strings')
    #server_address = ('localhost', 10000)
    strings = Read_File(file_name)  # Function Read the complete string file
    for lines in strings: # Read the string file by lines
        my_strings = lines.strip('\n')
        Send_Server(server_address, my_strings) # Send to server each string and Received the weight metric
    end_time= datetime.now()
    logging.info('Process completed in {} seconds'.format(end_time-start_time)) # Calculate the execution time


'''
if __name__ =='__main__' :
    
    Start(server_address, logfile_client, num_str, fname))
'''