import socket
import logging


# Server Processing File

def Weight_Metric(my_strings): # Calculate the weigth metric for each string on the file
    char = 0
    digits = 0
    bspace = 0
    for c in my_strings:
        if c.isalpha(): # If the c value is a-z or A-Z
          char += 1
        elif c.isdigit(): # If the c value is 0-9
           digits += 1
        elif c.isspace(): # If the c value is ' '
           bspace += 1
    return (char * 1.5 + digits * 2) / bspace


# Server Configuration
server_address = ('localhost', 10000)  # Configure for the server host and port
logging.basicConfig(level=logging.DEBUG, filename='/home/yadisbel/Solution/logfile_server.log')


sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
logging.info('Starting up on {} port {}'.format(*server_address)) # Save the information on server logfile

sock.bind(server_address)
sock.listen(1)

while True:
  logging.info('Waiting for connection')
  connection, client_address = sock.accept()
  try:
    logging.info('Connection from', client_address)
    while True:
        data = connection.recv(2048).decode('utf-8') # Receiving data from the client as string
        logging.info('Data received {} '.format(data))
        if data : # Calculate the weight metric
            if ('aa' in data) or ('AA'in data) or ('aA' in data) or ('Aa' in data): # If exist double a in the string
                 logging.info('Weight Metric data send to client 1000 --Double a rule detected >> {} '.format(data))
                 result = '1000 --Double a rule detected >> {}'
                 connection.sendto(str(result).encode('utf-8'), client_address)
            else:
                 result = Weight_Metric(data)
                 logging.info('Weight Metric data send to client {}'.format(result))
                 connection.sendto(str(result).encode('utf-8'), client_address)
        else:
            logging.error('No data from client', client_address) # If the data is empty or null
            break
  finally:
    logging.info('Connection is closing')
    connection.close()
