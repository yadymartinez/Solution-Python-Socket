import Client


server_address = ('localhost', 10000)  # Configure host and port
logfile_server = '/home/yadisbel/Solution/logfile_server.log' # Filename to store the log in the server side log
logfile_client = '/home/yadisbel/Solution/logfile_client.log' # Filename to store the log in the server side log
string_file = '/home/yadisbel/Solution' # Path to store the String Filename "chains.txt"
num_str = 100
# It's necessary Start the Server before running the Client . Run Server.py
Client.Start(server_address, logfile_client, num_str, string_file)



